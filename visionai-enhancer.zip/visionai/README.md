# 🚀 VisionAI Enhancer

> AI-powered image enhancement SaaS — Real-ESRGAN × GFPGAN × Next.js × FastAPI

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app)
[![Deploy on Vercel](https://vercel.com/button)](https://vercel.com)

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 🧠 Real-ESRGAN | 4× super-resolution upscaling |
| 👤 GFPGAN | Face restoration from low-quality photos |
| ⚡ Instant | GPU-accelerated processing |
| 🎛️ 5 Modes | Auto, Portrait, Landscape, Photo, Artwork |
| 📦 Batch | Process multiple images at once |
| 🔌 API | Full REST API with OpenAPI docs |

---

## 🏗️ Architecture

```
visionai-enhancer/
├── frontend/          # Next.js 14 + TypeScript + Tailwind
├── backend/           # FastAPI + Python 3.11
│   ├── api/routes/    # upload, enhance, status, download
│   ├── services/      # ImageProcessor, StorageManager
│   └── models/        # Task model & store
├── deployment/        # Docker, docker-compose
└── docs/              # Setup, API, Deployment guides
```

---

## 🚀 Quick Start (Local)

### Prerequisites
- Node.js 20+
- Python 3.11+
- Git

### 1. Clone & Install

```bash
git clone https://github.com/yourname/visionai-enhancer
cd visionai-enhancer

# Backend
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp ../.env.example .env

# Frontend
cd ../frontend
npm install
cp ../.env.example .env.local
# Edit .env.local: set NEXT_PUBLIC_API_URL=http://localhost:8000
```

### 2. Run Development Servers

```bash
# Terminal 1 — Backend
cd backend
uvicorn main:app --reload --port 8000

# Terminal 2 — Frontend
cd frontend
npm run dev
```

Open **http://localhost:3000** 🎉

### OR: Run with Docker

```bash
cd deployment
docker-compose up --build
```

---

## 🤖 Enabling Real AI Models

The backend ships with a PIL-based fallback for testing.  
To enable actual Real-ESRGAN + GFPGAN:

### 1. Install GPU dependencies

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
pip install basicsr realesrgan gfpgan facexlib opencv-python-headless
```

### 2. Download models

```bash
mkdir -p backend/models

# Real-ESRGAN
wget -P backend/models \
  https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth

# GFPGAN
wget -P backend/models \
  https://github.com/TencentARC/GFPGAN/releases/download/v1.3.4/GFPGANv1.4.pth
```

### 3. Uncomment model code in `backend/services/image_processor.py`

Uncomment the `_load_models`, `_enhance_standard`, and `_enhance_with_face_restore` blocks.

---

## ☁️ Deployment

### Backend → Railway (Recommended)

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Select your repo, set root directory to `backend/`
3. Add environment variables from `.env.example`
4. Railway auto-detects `requirements.txt` and deploys

**Copy the Railway URL** (e.g. `https://visionai-backend.railway.app`)

### Frontend → Vercel

```bash
cd frontend
npx vercel --prod
# When prompted, set:
# NEXT_PUBLIC_API_URL = https://your-railway-url.railway.app
```

### OR: HuggingFace Spaces (Free GPU)

1. Create a new Space at [huggingface.co/spaces](https://huggingface.co/spaces)
2. Select **Docker** SDK, **T4 Small** hardware (free for limited hours)
3. Upload `backend/` files + set `SPACE_PORT=7860` env var
4. The `app.py` entry point starts uvicorn automatically

---

## 📡 API Reference

| Method | Endpoint | Description |
|--------|---------|-------------|
| `POST` | `/api/upload` | Upload image (multipart/form-data) |
| `POST` | `/api/enhance` | Start AI enhancement |
| `GET` | `/api/status/{task_id}` | Poll task progress |
| `GET` | `/api/download/{task_id}` | Download enhanced image |
| `DELETE` | `/api/cleanup/{task_id}` | Delete files |
| `GET` | `/api/health` | Health check |

**Interactive docs:** http://localhost:8000/api/docs

### Example — enhance an image via API

```bash
# 1. Upload
curl -X POST http://localhost:8000/api/upload \
  -F "file=@photo.jpg" | jq .file_id

# 2. Enhance (use file_id from step 1)
curl -X POST http://localhost:8000/api/enhance \
  -H "Content-Type: application/json" \
  -d '{"file_id":"YOUR_FILE_ID","mode":"auto","scale":4}' | jq .task_id

# 3. Poll status
curl http://localhost:8000/api/status/YOUR_TASK_ID | jq .

# 4. Download when status == "completed"
curl -O http://localhost:8000/api/download/YOUR_TASK_ID
```

---

## 🔒 Security

- File type validated by MIME signature (not just extension)
- Rate limiting: 20 requests/minute per IP
- Input sanitization on all endpoints
- CORS configured per environment
- Non-root Docker user
- No credentials in code — all via env vars

---

## 🗺️ Roadmap

- [ ] Redis task queue (Celery) for multi-worker support
- [ ] Cloudinary/S3 for persistent storage
- [ ] Stripe billing integration
- [ ] User auth (NextAuth.js)
- [ ] Batch ZIP download
- [ ] WebSocket real-time progress
- [ ] PostHog analytics

---

## 📄 License

MIT © 2026 VisionAI Enhancer
