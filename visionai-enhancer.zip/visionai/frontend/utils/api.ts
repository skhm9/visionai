import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
});

export interface UploadResponse {
  file_id: string;
  filename: string;
  size_mb: number;
  mime_type: string;
  uploaded_at: string;
}

export interface EnhanceResponse {
  task_id: string;
  file_id: string;
  mode: string;
  scale: number;
  status: string;
  created_at: string;
}

export interface TaskStatus {
  task_id: string;
  status: "queued" | "processing" | "completed" | "failed";
  progress: number;
  mode: string;
  scale: number;
  download_url?: string;
  error?: string;
  processing_time_seconds?: number;
}

export const visionAPI = {
  async uploadImage(file: File): Promise<UploadResponse> {
    const form = new FormData();
    form.append("file", file);
    const res = await api.post("/api/upload", form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return res.data;
  },

  async enhanceImage(
    fileId: string,
    mode: string = "auto",
    scale: number = 4
  ): Promise<EnhanceResponse> {
    const res = await api.post("/api/enhance", { file_id: fileId, mode, scale });
    return res.data;
  },

  async getStatus(taskId: string): Promise<TaskStatus> {
    const res = await api.get(`/api/status/${taskId}`);
    return res.data;
  },

  getDownloadUrl(taskId: string): string {
    return `${API_URL}/api/download/${taskId}`;
  },

  async pollUntilDone(
    taskId: string,
    onProgress: (status: TaskStatus) => void,
    intervalMs: number = 1000
  ): Promise<TaskStatus> {
    return new Promise((resolve, reject) => {
      const poll = setInterval(async () => {
        try {
          const status = await visionAPI.getStatus(taskId);
          onProgress(status);
          if (status.status === "completed") {
            clearInterval(poll);
            resolve(status);
          } else if (status.status === "failed") {
            clearInterval(poll);
            reject(new Error(status.error || "Processing failed"));
          }
        } catch (err) {
          clearInterval(poll);
          reject(err);
        }
      }, intervalMs);
    });
  },
};
