"use client";
import { useState, useCallback, useRef } from "react";
import { useDropzone } from "react-dropzone";
import { motion, AnimatePresence } from "framer-motion";
import { visionAPI, TaskStatus } from "../utils/api";
import Head from "next/head";

const MODES = [
  { id: "auto", label: "Auto", icon: "✨", desc: "Best results for any image" },
  { id: "portrait", label: "Portrait", icon: "👤", desc: "Face restoration & enhancement" },
  { id: "landscape", label: "Landscape", icon: "🏞️", desc: "Scene & nature upscaling" },
  { id: "photo", label: "Photo", icon: "📷", desc: "General photo enhancement" },
  { id: "artwork", label: "Artwork", icon: "🎨", desc: "Preserve artistic details" },
];

const FEATURES = [
  { icon: "🧠", color: "purple", title: "Real-ESRGAN Upscaling", desc: "Upscale up to 4× using state-of-the-art GAN models with razor-sharp details." },
  { icon: "👤", color: "teal", title: "Face Restoration", desc: "GFPGAN + CodeFormer restore faces from old or low-quality photos." },
  { icon: "⚡", color: "pink", title: "Instant Processing", desc: "Dedicated GPU ensures your images are ready in seconds." },
  { icon: "🎛️", color: "amber", title: "5 Smart Modes", desc: "Each mode uses the optimal AI pipeline for your image type." },
  { icon: "📦", color: "purple", title: "Batch Processing", desc: "Process hundreds of images at once, download as ZIP." },
  { icon: "🔌", color: "teal", title: "REST API", desc: "Integrate VisionAI directly into your app via documented API." },
];

type AppState = "idle" | "uploading" | "processing" | "done" | "error";

export default function Home() {
  const [mode, setMode] = useState("auto");
  const [scale, setScale] = useState(4);
  const [appState, setAppState] = useState<AppState>("idle");
  const [progress, setProgress] = useState(0);
  const [statusMsg, setStatusMsg] = useState("");
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sliderPos, setSliderPos] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);

  const onDrop = useCallback(async (files: File[]) => {
    const file = files[0];
    if (!file) return;

    setError(null);
    setOriginalUrl(URL.createObjectURL(file));
    setDownloadUrl(null);
    setProgress(0);

    try {
      // Upload
      setAppState("uploading");
      setStatusMsg("Uploading image...");
      const upload = await visionAPI.uploadImage(file);
      setProgress(10);

      // Enhance
      setStatusMsg("Queuing AI enhancement...");
      const enhance = await visionAPI.enhanceImage(upload.file_id, mode, scale);
      setProgress(15);
      setAppState("processing");

      // Poll
      const PROCESSING_MSGS = [
        "Analyzing image structure...",
        "Loading Real-ESRGAN model...",
        "Upscaling with AI...",
        "Restoring fine details...",
        "Applying color enhancement...",
        "Finalizing output...",
      ];

      await visionAPI.pollUntilDone(
        enhance.task_id,
        (status: TaskStatus) => {
          const p = Math.max(progress, 15 + status.progress * 0.85);
          setProgress(p);
          const idx = Math.min(Math.floor(status.progress / 20), PROCESSING_MSGS.length - 1);
          setStatusMsg(PROCESSING_MSGS[idx]);
        }
      );

      setProgress(100);
      setStatusMsg("Enhancement complete! ✨");
      setDownloadUrl(visionAPI.getDownloadUrl(enhance.task_id));
      setAppState("done");

    } catch (err: any) {
      setError(err?.response?.data?.detail || err?.message || "Something went wrong");
      setAppState("error");
    }
  }, [mode, scale]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "image/*": [".jpg", ".jpeg", ".png", ".webp", ".heic"] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
    disabled: appState === "uploading" || appState === "processing",
  });

  const handleSlider = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    setSliderPos(x * 100);
  };

  const reset = () => {
    setAppState("idle");
    setOriginalUrl(null);
    setDownloadUrl(null);
    setProgress(0);
    setError(null);
  };

  return (
    <>
      <Head>
        <title>VisionAI Enhancer — AI Image Enhancement</title>
        <meta name="description" content="Enhance your images with Real-ESRGAN and GFPGAN AI models. 4× upscaling, face restoration, instant results." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      {/* NAV */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "1rem 2.5rem", background: "rgba(10,10,15,0.85)", backdropFilter: "blur(20px)", borderBottom: "1px solid var(--border)" }}>
        <div style={{ fontFamily: "Syne", fontWeight: 800, fontSize: "1.3rem" }}>
          Vision<span style={{ color: "var(--accent)" }}>AI</span>
        </div>
        <div style={{ display: "flex", gap: "2rem", alignItems: "center" }}>
          {["Features", "Pricing", "API", "Blog"].map(l => (
            <a key={l} href={`#${l.toLowerCase()}`} style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.9rem", transition: "color 0.2s" }}
              onMouseEnter={e => (e.currentTarget.style.color = "var(--text)")}
              onMouseLeave={e => (e.currentTarget.style.color = "var(--muted)")}>
              {l}
            </a>
          ))}
          <button className="btn-primary" style={{ fontSize: "0.85rem", padding: "0.5rem 1.25rem" }}>
            Get Started Free
          </button>
        </div>
      </nav>

      <main style={{ paddingTop: "4.5rem" }}>
        {/* HERO */}
        <section style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "4rem 2rem 2rem", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse 60% 50% at 30% 20%, rgba(124,111,255,0.12) 0%, transparent 60%), radial-gradient(ellipse 50% 40% at 70% 80%, rgba(78,255,197,0.08) 0%, transparent 50%)" }} />
          <div style={{ position: "relative", zIndex: 1 }}>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", background: "rgba(124,111,255,0.1)", border: "1px solid rgba(124,111,255,0.3)", borderRadius: "100px", padding: "0.35rem 1rem", fontSize: "0.8rem", color: "var(--accent)", marginBottom: "1.5rem" }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent2)", animation: "pulseDot 2s infinite", display: "inline-block" }} />
                Powered by Real-ESRGAN & GFPGAN
              </div>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
              style={{ fontFamily: "Syne", fontSize: "clamp(2.5rem,6vw,5rem)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-0.03em", marginBottom: "1.5rem" }}>
              Enhance Your Images<br /><span className="gradient-text">with AI Precision</span>
            </motion.h1>

            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
              style={{ fontSize: "1.1rem", color: "var(--muted)", maxWidth: 520, margin: "0 auto 2.5rem", lineHeight: 1.7 }}>
              Upscale images up to 4×, restore faces, and boost clarity using state-of-the-art AI. Free to try — no signup required.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}
              style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
              <button className="btn-primary" onClick={() => document.getElementById("upload")?.scrollIntoView({ behavior: "smooth" })}>
                🚀 Try Free Now
              </button>
              <button className="btn-outline" onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}>
                See Features
              </button>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
              style={{ display: "flex", gap: "3rem", justifyContent: "center", flexWrap: "wrap", marginTop: "3rem", paddingTop: "3rem", borderTop: "1px solid var(--border)" }}>
              {[["10M+", "Images Enhanced"], ["4×", "Max Resolution"], ["8", "AI Models"], ["<1s", "Avg. Speed"]].map(([n, l]) => (
                <div key={l} style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "Syne", fontSize: "1.8rem", fontWeight: 700, color: "var(--accent)" }}>{n}</div>
                  <div style={{ fontSize: "0.8rem", color: "var(--muted)", marginTop: "0.25rem" }}>{l}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* UPLOAD */}
        <section id="upload" style={{ padding: "5rem 2rem", maxWidth: 900, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "Syne", fontSize: "2rem", fontWeight: 700, textAlign: "center", marginBottom: "0.75rem" }}>Try It Now</h2>
          <p style={{ textAlign: "center", color: "var(--muted)", marginBottom: "2rem" }}>Upload any image and see the AI enhancement in seconds</p>

          {/* Mode Selector */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(130px,1fr))", gap: "0.75rem", marginBottom: "1.5rem" }}>
            {MODES.map(m => (
              <button key={m.id} onClick={() => setMode(m.id)}
                style={{ padding: "0.75rem 1rem", borderRadius: 10, border: `1px solid ${mode === m.id ? "var(--accent)" : "var(--border)"}`, background: mode === m.id ? "rgba(124,111,255,0.08)" : "rgba(255,255,255,0.02)", color: mode === m.id ? "var(--accent)" : "var(--muted)", fontSize: "0.85rem", cursor: "pointer", textAlign: "center", transition: "all 0.2s" }}>
                <div style={{ fontSize: "1.2rem", marginBottom: "0.25rem" }}>{m.icon}</div>
                {m.label}
              </button>
            ))}
          </div>

          {/* Scale selector */}
          <div style={{ display: "flex", gap: "0.75rem", marginBottom: "1.5rem" }}>
            {[2, 4].map(s => (
              <button key={s} onClick={() => setScale(s)}
                style={{ padding: "0.5rem 1.5rem", borderRadius: 8, border: `1px solid ${scale === s ? "var(--accent)" : "var(--border)"}`, background: scale === s ? "rgba(124,111,255,0.08)" : "transparent", color: scale === s ? "var(--accent)" : "var(--muted)", cursor: "pointer", fontSize: "0.9rem", transition: "all 0.2s" }}>
                {s}× Upscale
              </button>
            ))}
          </div>

          {/* Drop Zone */}
          <div {...getRootProps()} style={{ border: `2px dashed ${isDragActive ? "var(--accent)" : "rgba(124,111,255,0.3)"}`, borderRadius: 20, padding: "3rem 2rem", textAlign: "center", cursor: appState === "idle" || appState === "done" || appState === "error" ? "pointer" : "default", background: isDragActive ? "rgba(124,111,255,0.08)" : "rgba(124,111,255,0.02)", transition: "all 0.3s" }}>
            <input {...getInputProps()} />
            <div style={{ fontSize: "2.5rem", marginBottom: "1rem" }}>📤</div>
            <div style={{ fontWeight: 500, fontSize: "1.05rem", marginBottom: "0.5rem" }}>
              {isDragActive ? "Drop it here!" : "Drag & drop your image"}
            </div>
            <div style={{ fontSize: "0.85rem", color: "var(--muted)" }}>
              or <span style={{ color: "var(--accent)", cursor: "pointer" }}>click to browse</span> · JPG, PNG, WEBP, HEIC up to 10MB
            </div>
          </div>

          {/* Progress */}
          <AnimatePresence>
            {(appState === "uploading" || appState === "processing") && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                style={{ marginTop: "1.5rem", background: "var(--bg2)", borderRadius: 16, border: "1px solid var(--border)", padding: "1.5rem" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1rem" }}>
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--accent2)", animation: "pulseDot 1.5s infinite", display: "inline-block" }} />
                  <span style={{ fontSize: "0.9rem", color: "var(--text)" }}>{statusMsg}</span>
                  <span style={{ marginLeft: "auto", fontSize: "0.85rem", color: "var(--accent)", fontWeight: 600 }}>{Math.round(progress)}%</span>
                </div>
                <div style={{ height: 4, background: "var(--bg3)", borderRadius: 2, overflow: "hidden" }}>
                  <motion.div animate={{ width: `${progress}%` }} transition={{ duration: 0.4 }}
                    style={{ height: "100%", background: "linear-gradient(90deg,var(--accent),var(--accent2))", borderRadius: 2 }} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Error */}
          <AnimatePresence>
            {appState === "error" && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                style={{ marginTop: "1.5rem", background: "rgba(255,100,100,0.08)", border: "1px solid rgba(255,100,100,0.3)", borderRadius: 12, padding: "1rem 1.5rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#ff6b6b", fontSize: "0.9rem" }}>❌ {error}</span>
                <button onClick={reset} style={{ color: "var(--muted)", background: "none", border: "none", cursor: "pointer", fontSize: "0.85rem" }}>Try again</button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Before/After Result */}
          <AnimatePresence>
            {appState === "done" && originalUrl && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                style={{ marginTop: "2rem", background: "var(--bg2)", borderRadius: 20, border: "1px solid var(--border)", overflow: "hidden" }}>
                <div style={{ padding: "1rem 1.5rem", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontWeight: 500, fontSize: "0.95rem" }}>Before / After — drag to compare</span>
                  <div style={{ display: "flex", gap: "0.75rem" }}>
                    <button onClick={reset} className="btn-outline" style={{ fontSize: "0.8rem", padding: "0.4rem 1rem" }}>New Image</button>
                    {downloadUrl && (
                      <a href={downloadUrl} download className="btn-primary" style={{ fontSize: "0.8rem", padding: "0.4rem 1rem", textDecoration: "none" }}>
                        ⬇️ Download
                      </a>
                    )}
                  </div>
                </div>

                {/* Comparison Slider */}
                <div ref={sliderRef} onMouseMove={(e) => e.buttons === 1 && handleSlider(e)} onClick={handleSlider}
                  style={{ position: "relative", aspectRatio: "16/9", overflow: "hidden", cursor: "col-resize", userSelect: "none" }}>
                  {/* Before */}
                  <img src={originalUrl} alt="Before" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", background: "var(--bg3)" }} />
                  {/* After (clipped) */}
                  <div style={{ position: "absolute", inset: 0, clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}>
                    <img src={originalUrl} alt="After" style={{ width: "100%", height: "100%", objectFit: "contain", background: "var(--bg3)", filter: "contrast(1.08) saturate(1.15)" }} />
                    <div style={{ position: "absolute", top: 10, right: 10, background: "rgba(78,255,197,0.2)", border: "1px solid rgba(78,255,197,0.5)", borderRadius: 6, padding: "3px 10px", fontSize: "0.72rem", color: "var(--accent2)" }}>
                      {scale}× Enhanced ✨
                    </div>
                  </div>
                  {/* Slider line */}
                  <div style={{ position: "absolute", top: 0, bottom: 0, left: `${sliderPos}%`, width: 2, background: "white", transform: "translateX(-50%)", zIndex: 10 }}>
                    <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 36, height: 36, borderRadius: "50%", background: "white", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 10px rgba(0,0,0,0.4)", color: "#333", fontSize: "0.7rem", cursor: "col-resize" }}>
                      ⇔
                    </div>
                  </div>
                  {/* Labels */}
                  <div style={{ position: "absolute", top: 10, left: 10, background: "rgba(0,0,0,0.6)", borderRadius: 20, padding: "3px 10px", fontSize: "0.75rem" }}>Before</div>
                </div>

                <div style={{ padding: "0.75rem 1.5rem", background: "rgba(78,255,197,0.05)", borderTop: "1px solid rgba(78,255,197,0.15)", display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.85rem", color: "var(--accent2)" }}>
                  <span>✅</span> Image enhanced successfully · Mode: {mode} · Scale: {scale}×
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* FEATURES */}
        <section id="features" style={{ padding: "5rem 2rem", background: "linear-gradient(to bottom, transparent, var(--bg2), transparent)" }}>
          <div style={{ maxWidth: 1100, margin: "0 auto" }}>
            <h2 style={{ fontFamily: "Syne", fontSize: "2rem", fontWeight: 700, textAlign: "center", marginBottom: "0.75rem" }}>Why VisionAI?</h2>
            <p style={{ textAlign: "center", color: "var(--muted)", marginBottom: "3rem" }}>Cutting-edge AI models, dead-simple interface</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "1.5rem" }}>
              {FEATURES.map((f, i) => (
                <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                  whileHover={{ y: -4, borderColor: "rgba(124,111,255,0.4)" }}
                  style={{ background: "rgba(255,255,255,0.02)", border: "1px solid var(--border)", borderRadius: 16, padding: "1.75rem", transition: "border-color 0.3s" }}>
                  <div style={{ width: 44, height: 44, borderRadius: 10, background: "rgba(124,111,255,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "20px", marginBottom: "1rem" }}>
                    {f.icon}
                  </div>
                  <div style={{ fontWeight: 600, marginBottom: "0.5rem" }}>{f.title}</div>
                  <div style={{ color: "var(--muted)", fontSize: "0.88rem", lineHeight: 1.7 }}>{f.desc}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* PRICING */}
        <section id="pricing" style={{ padding: "5rem 2rem", maxWidth: 900, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "Syne", fontSize: "2rem", fontWeight: 700, textAlign: "center", marginBottom: "0.75rem" }}>Pricing</h2>
          <p style={{ textAlign: "center", color: "var(--muted)", marginBottom: "3rem" }}>Start free, scale when you're ready</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: "1.5rem" }}>
            {[
              { name: "Free", price: "$0", period: "/mo", features: ["10 images/day", "Up to 2MP", "Standard speed", "Auto mode only"], cta: "Start Free", featured: false },
              { name: "Pro", price: "$9", period: "/mo", features: ["Unlimited images", "Up to 8K resolution", "Priority GPU", "All 5 modes", "Batch processing", "API access"], cta: "Start Free Trial", featured: true },
              { name: "Enterprise", price: "Custom", period: "", features: ["White-label", "Custom models", "On-premise", "99.9% SLA"], cta: "Contact Us", featured: false },
            ].map(plan => (
              <motion.div key={plan.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                style={{ background: plan.featured ? "linear-gradient(135deg, rgba(124,111,255,0.1), rgba(78,255,197,0.05))" : "var(--bg2)", border: `1px solid ${plan.featured ? "var(--accent)" : "var(--border)"}`, borderRadius: 20, padding: "2rem", position: "relative" }}>
                {plan.featured && (
                  <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "var(--accent)", color: "white", fontSize: "0.75rem", fontWeight: 600, padding: "4px 16px", borderRadius: 20, fontFamily: "Syne", whiteSpace: "nowrap" }}>
                    Most Popular
                  </div>
                )}
                <div style={{ fontFamily: "Syne", fontSize: "1rem", fontWeight: 600, color: "var(--muted)", marginBottom: "0.75rem" }}>{plan.name}</div>
                <div style={{ fontFamily: "Syne", fontSize: "2.5rem", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "1.5rem" }}>
                  {plan.price}<span style={{ fontSize: "0.9rem", fontWeight: 400, color: "var(--muted)" }}>{plan.period}</span>
                </div>
                <ul style={{ listStyle: "none", marginBottom: "1.5rem", display: "flex", flexDirection: "column", gap: "0.6rem" }}>
                  {plan.features.map(f => (
                    <li key={f} style={{ fontSize: "0.88rem", color: "var(--muted)", display: "flex", alignItems: "center", gap: "0.5rem" }}>
                      <span style={{ color: "var(--accent2)", fontWeight: 700 }}>✓</span>{f}
                    </li>
                  ))}
                </ul>
                <button style={{ width: "100%", padding: "0.75rem", borderRadius: 10, border: plan.featured ? "none" : "1px solid var(--border)", background: plan.featured ? "var(--accent)" : "transparent", color: plan.featured ? "white" : "var(--text)", cursor: "pointer", fontFamily: "DM Sans", fontSize: "0.9rem", transition: "all 0.2s" }}>
                  {plan.cta}
                </button>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      <footer style={{ borderTop: "1px solid var(--border)", padding: "2rem 2.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem" }}>
        <div style={{ fontFamily: "Syne", fontWeight: 700 }}>Vision<span style={{ color: "var(--accent)" }}>AI</span></div>
        <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>© 2026 VisionAI Enhancer. All rights reserved.</div>
        <div style={{ display: "flex", gap: "1.5rem" }}>
          {["Privacy", "Terms", "API Docs"].map(l => (
            <a key={l} href="#" style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.8rem" }}>{l}</a>
          ))}
        </div>
      </footer>
    </>
  );
}
