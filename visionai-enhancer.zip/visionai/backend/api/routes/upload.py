from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
import uuid
import os
import magic
import aiofiles
import logging
from datetime import datetime

from config.settings import Settings
from services.storage_manager import StorageManager

router = APIRouter()
logger = logging.getLogger(__name__)
settings = Settings()
storage = StorageManager()

ALLOWED_MIME_TYPES = {
    "image/jpeg", "image/png", "image/webp",
    "image/heic", "image/bmp", "image/tiff"
}

@router.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    """Upload an image for enhancement."""

    # Validate file size
    content = await file.read()
    size_mb = len(content) / (1024 * 1024)
    if size_mb > settings.MAX_FILE_SIZE_MB:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum size is {settings.MAX_FILE_SIZE_MB}MB, got {size_mb:.1f}MB"
        )

    # Validate MIME type (not just extension — security best practice)
    mime_type = magic.from_buffer(content[:2048], mime=True)
    if mime_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type: {mime_type}. Allowed: JPEG, PNG, WEBP, HEIC, BMP, TIFF"
        )

    # Validate extension
    ext = os.path.splitext(file.filename or "")[1].lower().lstrip(".")
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail=f"File extension .{ext} not allowed."
        )

    # Save file
    file_id = str(uuid.uuid4())
    filename = f"{file_id}.{ext}"
    upload_path = os.path.join(settings.UPLOAD_DIR, filename)

    async with aiofiles.open(upload_path, "wb") as f:
        await f.write(content)

    logger.info(f"Uploaded file: {filename} ({size_mb:.2f}MB, {mime_type})")

    return JSONResponse({
        "file_id": file_id,
        "filename": file.filename,
        "size_mb": round(size_mb, 2),
        "mime_type": mime_type,
        "uploaded_at": datetime.utcnow().isoformat(),
        "message": "File uploaded successfully. Use /api/enhance to start processing."
    })
