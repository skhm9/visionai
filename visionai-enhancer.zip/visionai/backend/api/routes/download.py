from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
import os
import logging

from models.task import task_store, TaskStatus
from config.settings import Settings

router = APIRouter()
logger = logging.getLogger(__name__)
settings = Settings()

@router.get("/download/{task_id}")
async def download_result(task_id: str):
    """Download the enhanced image."""
    task = task_store.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    if task.status != TaskStatus.COMPLETED:
        raise HTTPException(
            status_code=400,
            detail=f"Task not ready. Current status: {task.status.value}"
        )

    if not task.output_path or not os.path.exists(task.output_path):
        raise HTTPException(status_code=404, detail="Output file not found")

    filename = os.path.basename(task.output_path)
    logger.info(f"Serving download: {filename}")

    return FileResponse(
        path=task.output_path,
        filename=f"visionai_enhanced_{filename}",
        media_type="image/png",
    )

@router.delete("/cleanup/{task_id}")
async def cleanup_task(task_id: str):
    """Delete processed files to free storage."""
    task = task_store.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    deleted = []
    for path in [task.input_path, task.output_path]:
        if path and os.path.exists(path):
            os.remove(path)
            deleted.append(path)

    del task_store[task_id]
    return {"message": "Cleaned up", "deleted_files": len(deleted)}
