from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

from models.task import task_store, TaskStatus

router = APIRouter()

@router.get("/status/{task_id}")
async def get_status(task_id: str):
    """Check the processing status of a task."""
    task = task_store.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task not found: {task_id}")

    response = {
        "task_id": task_id,
        "status": task.status.value,
        "progress": task.progress,
        "mode": task.mode,
        "scale": task.scale,
        "created_at": task.created_at.isoformat(),
    }

    if task.status == TaskStatus.COMPLETED:
        response["output_path"] = task.output_path
        response["download_url"] = f"/api/download/{task_id}"
        response["completed_at"] = task.completed_at.isoformat() if task.completed_at else None
        response["processing_time_seconds"] = task.processing_time

    if task.status == TaskStatus.FAILED:
        response["error"] = task.error_message

    return JSONResponse(response)
