from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel, validator
import uuid
import os
import logging
from datetime import datetime
from typing import Optional

from config.settings import Settings
from services.image_processor import ImageProcessor
from models.task import Task, TaskStatus, task_store

router = APIRouter()
logger = logging.getLogger(__name__)
settings = Settings()
processor = ImageProcessor()

class EnhanceRequest(BaseModel):
    file_id: str
    mode: str = "auto"
    scale: int = 4
    face_enhance: bool = False

    @validator("mode")
    def validate_mode(cls, v):
        allowed = {"auto", "portrait", "landscape", "photo", "artwork"}
        if v not in allowed:
            raise ValueError(f"Mode must be one of: {', '.join(allowed)}")
        return v

    @validator("scale")
    def validate_scale(cls, v):
        if v not in (2, 4):
            raise ValueError("Scale must be 2 or 4")
        return v

@router.post("/enhance")
async def enhance_image(request: EnhanceRequest, background_tasks: BackgroundTasks):
    """Trigger AI enhancement on an uploaded image."""

    # Find uploaded file
    upload_path = None
    for ext in settings.ALLOWED_EXTENSIONS:
        candidate = os.path.join(settings.UPLOAD_DIR, f"{request.file_id}.{ext}")
        if os.path.exists(candidate):
            upload_path = candidate
            break

    if not upload_path:
        raise HTTPException(status_code=404, detail=f"File not found: {request.file_id}")

    # Create task
    task_id = str(uuid.uuid4())
    task = Task(
        task_id=task_id,
        file_id=request.file_id,
        mode=request.mode,
        scale=request.scale,
        face_enhance=request.face_enhance or request.mode == "portrait",
        input_path=upload_path,
        status=TaskStatus.QUEUED,
        created_at=datetime.utcnow(),
    )
    task_store[task_id] = task

    # Run in background
    background_tasks.add_task(processor.process_task, task)

    logger.info(f"Task {task_id} queued: mode={request.mode}, scale={request.scale}x")

    return JSONResponse({
        "task_id": task_id,
        "file_id": request.file_id,
        "mode": request.mode,
        "scale": request.scale,
        "status": "queued",
        "message": "Enhancement started. Poll /api/status/{task_id} for progress.",
        "created_at": task.created_at.isoformat(),
    })
