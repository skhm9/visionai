from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import time
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Simple in-memory rate limiter: max N requests per window per IP.
    Replace with Redis-backed limiter in production for multi-instance support.
    """

    def __init__(self, app, max_requests: int = 20, window_seconds: int = 60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._store: dict[str, list[float]] = defaultdict(list)

    def _get_client_ip(self, request: Request) -> str:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for health checks and docs
        if request.url.path in ("/api/health", "/api/docs", "/api/redoc", "/"):
            return await call_next(request)

        ip = self._get_client_ip(request)
        now = time.time()
        window_start = now - self.window_seconds

        # Remove expired entries
        self._store[ip] = [t for t in self._store[ip] if t > window_start]

        if len(self._store[ip]) >= self.max_requests:
            logger.warning(f"Rate limit exceeded: {ip}")
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Rate limit exceeded",
                    "message": f"Maximum {self.max_requests} requests per {self.window_seconds}s",
                    "retry_after": int(self._store[ip][0] + self.window_seconds - now),
                },
                headers={"Retry-After": str(int(self._store[ip][0] + self.window_seconds - now))},
            )

        self._store[ip].append(now)
        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(self.max_requests)
        response.headers["X-RateLimit-Remaining"] = str(self.max_requests - len(self._store[ip]))
        return response
