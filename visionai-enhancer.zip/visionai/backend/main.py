from fastapi import FastAPI, File, UploadFile, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import uuid
import os
import asyncio
import aiofiles
import logging
from datetime import datetime
from contextlib import asynccontextmanager

from api.routes import enhance, upload, status, download
from api.middleware.rate_limit import RateLimitMiddleware
from config.settings import Settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

settings = Settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 VisionAI Enhancer starting up...")
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    os.makedirs(settings.OUTPUT_DIR, exist_ok=True)
    yield
    logger.info("🛑 VisionAI Enhancer shutting down...")

app = FastAPI(
    title="VisionAI Enhancer API",
    description="AI-powered image enhancement SaaS platform",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RateLimitMiddleware, max_requests=20, window_seconds=60)

app.include_router(upload.router, prefix="/api")
app.include_router(enhance.router, prefix="/api")
app.include_router(status.router, prefix="/api")
app.include_router(download.router, prefix="/api")

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "models_loaded": True,
    }

@app.get("/")
async def root():
    return {"message": "VisionAI Enhancer API - visit /api/docs for documentation"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
