"""
HuggingFace Spaces entry point for VisionAI Backend.

Deploy steps:
1. Create a new Space at huggingface.co/spaces
2. Select "Docker" as the SDK
3. Upload all backend files + this file
4. Set hardware to "CPU Basic" (free) or "T4 Small" (GPU, paid)
"""
import subprocess
import sys
import os

# HuggingFace Spaces runs on port 7860
os.environ.setdefault("PORT", "7860")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 7860))
    subprocess.run([
        sys.executable, "-m", "uvicorn",
        "main:app",
        "--host", "0.0.0.0",
        "--port", str(port),
    ])
