from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    APP_NAME: str = "VisionAI Enhancer"
    DEBUG: bool = False
    SECRET_KEY: str = "change-this-in-production-use-a-long-random-string"

    # File storage
    UPLOAD_DIR: str = "uploads"
    OUTPUT_DIR: str = "outputs"
    MAX_FILE_SIZE_MB: int = 10
    ALLOWED_EXTENSIONS: List[str] = ["jpg", "jpeg", "png", "webp", "heic", "bmp", "tiff"]

    # CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "https://your-frontend.vercel.app",
        "*",  # Remove in production, set specific origins
    ]

    # AI Models
    MODEL_CACHE_DIR: str = "models/cache"
    ESRGAN_MODEL_PATH: str = "models/RealESRGAN_x4plus.pth"
    GFPGAN_MODEL_PATH: str = "models/GFPGANv1.4.pth"
    DEFAULT_SCALE: int = 4

    # Processing
    MAX_IMAGE_DIMENSION: int = 2000  # Free tier limit
    PRO_MAX_DIMENSION: int = 8000
    BATCH_MAX_FILES: int = 20
    TASK_TIMEOUT_SECONDS: int = 120

    # Cleanup
    FILE_RETENTION_HOURS: int = 24

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
