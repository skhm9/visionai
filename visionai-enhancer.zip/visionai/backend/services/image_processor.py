import os
import time
import logging
import asyncio
from datetime import datetime
from typing import Optional
from pathlib import Path

from models.task import Task, TaskStatus
from config.settings import Settings

logger = logging.getLogger(__name__)
settings = Settings()


class ImageProcessor:
    """
    Core AI image enhancement engine.
    Integrates Real-ESRGAN for upscaling and GFPGAN for face restoration.

    In production, replace the stub methods below with actual model inference.
    Models are loaded lazily on first use to reduce startup time.
    """

    def __init__(self):
        self._esrgan_model = None
        self._gfpgan_model = None
        self._models_loaded = False

    def _load_models(self):
        """Lazy-load AI models. Called on first inference request."""
        if self._models_loaded:
            return
        try:
            # --- Real-ESRGAN ---
            # from basicsr.archs.rrdbnet_arch import RRDBNet
            # from realesrgan import RealESRGANer
            # model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64,
            #                 num_block=23, num_grow_ch=32, scale=4)
            # self._esrgan_model = RealESRGANer(
            #     scale=4, model_path=settings.ESRGAN_MODEL_PATH,
            #     model=model, tile=400, tile_pad=10, pre_pad=0, half=False
            # )

            # --- GFPGAN ---
            # from gfpgan import GFPGANer
            # self._gfpgan_model = GFPGANer(
            #     model_path=settings.GFPGAN_MODEL_PATH, upscale=4,
            #     arch='clean', channel_multiplier=2,
            #     bg_upsampler=self._esrgan_model
            # )

            self._models_loaded = True
            logger.info("✅ AI models loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load models: {e}")
            # Fall through to stub mode for demo/testing

    async def process_task(self, task: Task):
        """Main entry point. Called as a background task."""
        task.status = TaskStatus.PROCESSING
        task.progress = 5
        start_time = time.time()

        try:
            output_path = await self._run_enhancement(task)
            task.output_path = output_path
            task.status = TaskStatus.COMPLETED
            task.progress = 100
            task.completed_at = datetime.utcnow()
            task.processing_time = round(time.time() - start_time, 2)
            logger.info(f"✅ Task {task.task_id} completed in {task.processing_time}s")

        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error_message = str(e)
            logger.error(f"❌ Task {task.task_id} failed: {e}")

    async def _run_enhancement(self, task: Task) -> str:
        """Run the appropriate enhancement pipeline based on mode."""
        self._load_models()

        # Determine output path
        input_stem = Path(task.input_path).stem
        output_filename = f"{input_stem}_enhanced_{task.scale}x.png"
        output_path = os.path.join(settings.OUTPUT_DIR, output_filename)

        if task.face_enhance or task.mode == "portrait":
            await self._enhance_with_face_restore(task, output_path)
        else:
            await self._enhance_standard(task, output_path)

        return output_path

    async def _enhance_standard(self, task: Task, output_path: str):
        """Standard upscaling with Real-ESRGAN."""
        task.progress = 20
        await asyncio.sleep(0.1)  # Yield to event loop

        # --- Production code ---
        # import cv2
        # import numpy as np
        # img = cv2.imread(task.input_path, cv2.IMREAD_UNCHANGED)
        # output, _ = self._esrgan_model.enhance(img, outscale=task.scale)
        # cv2.imwrite(output_path, output)

        # --- Demo stub: apply PIL-based enhancements ---
        await self._apply_pil_enhancement(task.input_path, output_path, task)

    async def _enhance_with_face_restore(self, task: Task, output_path: str):
        """Face restoration + upscaling with GFPGAN."""
        task.progress = 20
        await asyncio.sleep(0.1)

        # --- Production code ---
        # import cv2
        # img = cv2.imread(task.input_path, cv2.IMREAD_COLOR)
        # _, _, output = self._gfpgan_model.enhance(
        #     img, has_aligned=False, only_center_face=False, paste_back=True
        # )
        # cv2.imwrite(output_path, output)

        await self._apply_pil_enhancement(task.input_path, output_path, task)

    async def _apply_pil_enhancement(self, input_path: str, output_path: str, task: Task):
        """
        PIL-based enhancement fallback for demo/testing.
        Applies sharpening, contrast, and saturation improvements.
        Replace with actual model inference in production.
        """
        from PIL import Image, ImageEnhance, ImageFilter
        import asyncio

        task.progress = 40

        # Run in thread pool to avoid blocking event loop
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._pil_enhance_sync, input_path, output_path, task)

    def _pil_enhance_sync(self, input_path: str, output_path: str, task: Task):
        """Synchronous PIL enhancement (runs in thread pool)."""
        from PIL import Image, ImageEnhance, ImageFilter

        img = Image.open(input_path).convert("RGB")
        task.progress = 50

        # Upscale using high-quality Lanczos resampling
        new_w = img.width * task.scale
        new_h = img.height * task.scale
        img = img.resize((new_w, new_h), Image.LANCZOS)
        task.progress = 65

        # Apply enhancements based on mode
        if task.mode in ("portrait", "photo", "auto"):
            img = ImageEnhance.Sharpness(img).enhance(1.5)
            img = ImageEnhance.Contrast(img).enhance(1.08)
            img = ImageEnhance.Color(img).enhance(1.1)
        elif task.mode == "landscape":
            img = ImageEnhance.Sharpness(img).enhance(1.3)
            img = ImageEnhance.Contrast(img).enhance(1.12)
            img = ImageEnhance.Color(img).enhance(1.2)
            img = ImageEnhance.Brightness(img).enhance(1.05)
        elif task.mode == "artwork":
            img = ImageEnhance.Sharpness(img).enhance(1.8)
            img = ImageEnhance.Color(img).enhance(1.25)

        task.progress = 85
        img.save(output_path, "PNG", optimize=True)
        task.progress = 95
        logger.info(f"PIL enhancement complete: {output_path} ({new_w}x{new_h})")
