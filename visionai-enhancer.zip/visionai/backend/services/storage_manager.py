import os
import time
import logging
import asyncio
from pathlib import Path
from config.settings import Settings

logger = logging.getLogger(__name__)
settings = Settings()


class StorageManager:
    """Handles file storage, retrieval, and automated cleanup."""

    def __init__(self):
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        os.makedirs(settings.OUTPUT_DIR, exist_ok=True)

    def get_upload_path(self, file_id: str, ext: str) -> str:
        return os.path.join(settings.UPLOAD_DIR, f"{file_id}.{ext}")

    def get_output_path(self, file_id: str) -> str:
        return os.path.join(settings.OUTPUT_DIR, f"{file_id}_enhanced.png")

    def file_exists(self, path: str) -> bool:
        return os.path.exists(path)

    def delete_file(self, path: str) -> bool:
        try:
            if os.path.exists(path):
                os.remove(path)
                return True
        except Exception as e:
            logger.error(f"Failed to delete {path}: {e}")
        return False

    async def cleanup_old_files(self):
        """Remove files older than FILE_RETENTION_HOURS. Run as scheduled task."""
        cutoff = time.time() - (settings.FILE_RETENTION_HOURS * 3600)
        deleted = 0
        for directory in [settings.UPLOAD_DIR, settings.OUTPUT_DIR]:
            for filename in os.listdir(directory):
                filepath = os.path.join(directory, filename)
                if os.path.getmtime(filepath) < cutoff:
                    os.remove(filepath)
                    deleted += 1
        if deleted:
            logger.info(f"Cleaned up {deleted} old files")
        return deleted
