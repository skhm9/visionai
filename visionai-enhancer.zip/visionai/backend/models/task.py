from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from typing import Optional, Dict

class TaskStatus(str, Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class Task:
    task_id: str
    file_id: str
    mode: str
    scale: int
    face_enhance: bool
    input_path: str
    status: TaskStatus
    created_at: datetime
    output_path: Optional[str] = None
    progress: int = 0
    error_message: Optional[str] = None
    completed_at: Optional[datetime] = None
    processing_time: Optional[float] = None

# In-memory task store (replace with Redis in production)
task_store: Dict[str, Task] = {}
