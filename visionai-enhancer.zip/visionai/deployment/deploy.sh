#!/bin/bash
# VisionAI Enhancer — One-click deployment helper
set -e

echo "🚀 VisionAI Enhancer — Deployment Script"
echo "========================================="

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_step() { echo -e "\n${BLUE}▶ $1${NC}"; }
print_ok()   { echo -e "${GREEN}✅ $1${NC}"; }
print_warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }

# ── Frontend → Vercel ──────────────────────────────────────
deploy_frontend() {
  print_step "Deploying Frontend to Vercel..."
  cd frontend

  if ! command -v vercel &>/dev/null; then
    print_warn "Installing Vercel CLI..."
    npm i -g vercel
  fi

  vercel --prod
  print_ok "Frontend deployed!"
  cd ..
}

# ── Backend → Railway ──────────────────────────────────────
deploy_backend() {
  print_step "Deploying Backend to Railway..."
  cd backend

  if ! command -v railway &>/dev/null; then
    print_warn "Installing Railway CLI..."
    npm i -g @railway/cli
  fi

  railway login
  railway up
  print_ok "Backend deployed!"
  cd ..
}

# ── Docker (local/VPS) ─────────────────────────────────────
deploy_docker() {
  print_step "Deploying with Docker Compose..."
  cd deployment
  docker-compose pull
  docker-compose up -d --build
  print_ok "Docker stack running! Backend: http://localhost:8000, Frontend: http://localhost:3000"
  cd ..
}

# ── Main ───────────────────────────────────────────────────
case "${1:-docker}" in
  vercel)   deploy_frontend ;;
  railway)  deploy_backend ;;
  docker)   deploy_docker ;;
  all)      deploy_backend && deploy_frontend ;;
  *)
    echo "Usage: ./deploy.sh [docker|vercel|railway|all]"
    echo ""
    echo "  docker   — Local Docker Compose (default)"
    echo "  railway  — Deploy backend to Railway"
    echo "  vercel   — Deploy frontend to Vercel"
    echo "  all      — Deploy both to Railway + Vercel"
    ;;
esac
